﻿using Com.Cognizant.Truyum.Dao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Truyum.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            MenuItemDaoCollectionTest.TestGetMenuItemListAdmin();
            MenuItemDaoCollectionTest.TestModifyMenuItem();
            MenuItemDaoCollectionTest.TestGetMenuItemListCustomer();
            MenuItemDaoCollectionTest.TestGetMenuItem();
            CartDaoCollectionTest.TestAddCartItem();
            CartDaoCollectionTest.TestGetAllCartItems();

            CartDaoCollectionTest.TestRemoveCartItem();
        }
    }
}
